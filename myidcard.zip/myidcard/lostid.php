<?php
session_start();
if (!isset($_SESSION["reg"])) {
  header("location:index.php");
}
  require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM apply WHERE reg = '".$_SESSION['reg']."'";
$result = mysqli_query($connection,$sql);
if (isset($_POST["check"])) {
  require_once "db.php";
   $select = "SELECT * FROM status2  WHERE reg = '".$_SESSION['reg']."'";
   $display = mysqli_query($connection,$select);
   $row = mysqli_num_rows ($display);
   if ($row==1) {
      $success_message = "<div class = 'alert alert-success'>Your lost id card is ready for collection, thank you!</div>";
    }else{
    $error_message = "<div class = 'alert alert-danger'>Your lost id card is not yet ready for collection, thank you!</div>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="loggedin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
       <br>
           <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>LOST ID CARD APPLICATION PAGE<img src="auk.jpg" style="width: 30px; float: left;"></strong>
</h5>
        <?php 
        if (!empty($error_message)) {
          echo $error_message;
        } 
        if (!empty($success_message)) {
          echo $success_message;
        } 
               ?>
               <form action="" method="post">
           <h5 style="text-align: center;">
      <button type="submit" name="check" class="btn btn-success">
       Check for lost id-card availability</button></h5>
     </form>
      <form action="" enctype="multipart/form-data" method="post"class="form-group">
        <?php while ($row = $result->fetch_assoc()):?>
        <input type="text" name="image" class="form-control"  placeholder="<?php echo  $row['image'];?>" value = "<?php echo  $row['image'];?>"  required readonly>
      <h5><label>Reg NO:</label><input type="text" name="reg" class="form-control" placeholder="<?php echo  $_SESSION['reg'];?>" value = "<?php echo  $_SESSION['reg'];?>"  required readonly></h5>
      <h5><label>Surname:</label><input type="text" name="surname" class="form-control"  placeholder="<?php echo  $row['surname'];?>" value = "<?php echo  $row['surname'];?>"  required readonly ></h5>
      <h5><label>Othernames</label><input type="text" name="othernames" class="form-control"  placeholder="<?php echo  $row['othernames'];?>" value = "<?php echo  $row['othernames'];?>"  required readonly></h5>
      <h5><label>College:</label><input type="text" name="college" class="form-control" placeholder="<?php echo  $row['college'];?>" value = "<?php echo  $row['college'];?>"  required readonly></h5>
      <h5><label>Department</label><input type="text" name="department" class="form-control" placeholder="<?php echo  $row['department'];?>" value = "<?php echo  $row['department'];?>"  required readonly></h5>
      <h5><label>Course:</label><input type="text" name="course" class="form-control" placeholder="<?php echo  $row['course'];?>" value = "<?php echo  $row['course'];?>"  required readonly></h5>    
      <h5><label>Next of kin no:</label><input type="number" name="kinno" class="form-control" placeholder="<?php echo  $row['kinno'];?>" value = "<?php echo  $row['kinno'];?>"  required readonly></h5>
      <?php endwhile; ?>  
      <button class="btn btn-primary" name="submit">Apply</button>
      <br>
      <h5><a href = "loggedin.php">back</h5>
        </form>
    </div>
  </div>
</div>
</body>
</html>

<?php
if(isset($_POST['submit'])){
require_once("db.php");
$image = $_POST['image'];
$reg = $_POST['reg'];
$surname = $_POST['surname'];
$othernames = $_POST['othernames'];
$college = $_POST['college'];
$department = $_POST['department'];
$course = $_POST['course'];
$kinno = $_POST['kinno'];

$select = "SELECT * FROM lost WHERE reg = '$reg'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
  echo '<script>alert("You have already made a lost id-card Application!")</script></div>';
}else{
$i="INSERT INTO lost(image,reg,surname,othernames,college,department,course,kinno)values('$image','$reg','$surname','$othernames','$college','$department','$course','$kinno')";
mysqli_query($connection, $i);
  echo '<script>alert("Lost Id-Card Application Successful!")</script></div>';

}
}
?>