<?php
session_start();
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

  $connection = mysqli_connect($host,$username,$password);
  $db = mysqli_select_db($connection,$dbname);
 $reg = ($_POST['reg']);
$select = "SELECT * FROM signup WHERE reg = '".$_POST["reg"]."'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
  $_SESSION['reg'] = $reg; 
  header('location:forgotprocess.php');
 }
  else{
    $error_message = "<div class = 'alert alert-danger'>Invalid Registration Number</div>";
     }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="index.php"><strong><img src="auk.jpg" style="width: 40px;"> Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="index.php"><strong>Student</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
       <div class="row justify-content-center">
       	<div class="col-md-6 col-xs-12">
       	<div class="jumbotron" style="background-color: #fefcff">	
          <h5 align="center" class="alert alert-info" style="background-color: darkorange; color: black;"><strong>STUDENT PASSWORD RESET<img src="auk.jpg" style="width: 30px; float: left;"></strong>
</h5>
          <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
      <form action="" method="post"class="form-group">
			<h6><label>Reg no:</label><input type="name" name="reg" class="form-control" placeholder="reg no" maxlength="15"></h6>
			<button class="btn btn-primary" name="submit">Next</button>
        </form>
		</div>
	</div>
</div>
</body>
</html>
