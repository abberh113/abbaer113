admin.php
<?php
session_start();
if (isset($_POST['submit'])) {

$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

$connection = mysqli_connect($host,$username,$password);
$db = mysqli_select_db($connection,$dbname);

$user_name = mysqli_real_escape_string($connection,$_POST["user_name"]);
$passcode = mysqli_real_escape_string($connection,$_POST["passcode"]);

$select = "SELECT * FROM admin WHERE user_name = '$user_name' && passcode = '$passcode'";

$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
    $_SESSION['user_name'] = $user_name;
    header('location:adminloggedin.php');
 }
  else{
    $error_message = "<div class = 'alert alert-danger'>Invalid User or Password</div>";
     }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <strong><a class="navbar-brand" href="index.php"><img src="auk.jpg" style="width: 40px;"> Student id-card</a></strong>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="index.php"><strong>Student</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>    
 <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff"> 
          <h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;"><strong>ADMIN SIGN IN PAGE<img src="auk.jpg" style="width: 30px; float: left;"></strong>
</h5><?php if (!empty($error_message)) {
  echo $error_message;
} ?>
			<form action="" method="post"class="form-group">
			<h5><label>Username:</label><input type="name" name="user_name" class="form-control" placeholder="Username" maxlength="10"></h5>
			<h5><label>Password</label><input type="password" name="passcode" class="form-control" placeholder="password" min="0" max="10"></h5>
			<button class="btn btn-primary" name="submit">Login</button>
      <br>
			<a href = "adminreg.php">click here to sign up</a>
      <br>
      <a href = "forgot1.php">forgot password?</a>

        </form>
		</div>
	</div>
</div>
</body>
</html>

adminreg.php
<?php
if (isset($_POST['submit'])) {

$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

$connection = mysqli_connect($host,$username,$password);
$db = mysqli_select_db($connection,$dbname);

$user_name = mysqli_real_escape_string($connection,$_POST["user_name"]);
$passcode = mysqli_real_escape_string($connection,$_POST["passcode"]);
$passcode2 = mysqli_real_escape_string($connection,$_POST["passcode2"]);

if ($passcode != $passcode2) {
 $error_message = "<div class = 'alert alert-danger'>passcodes do not match</div>";
} else{

$select = "SELECT * FROM admin WHERE user_name = '$user_name' && passcode = '$passcode'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1){
     $error_message = "<div class = 'alert alert-danger'>Username already Registered</div>";
 }
  else{
    $insert = "INSERT INTO admin (user_name,passcode,passcode2) VALUES('$user_name','$passcode','$passcode2')";
    mysqli_query($connection,$insert);
    $success_message = "<div class = 'alert alert-success'>Registeration Successful</div>";
    }
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="admin.php"><strong><img src="auk.jpg" style="width: 40px;"> Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="index.php"><strong>Student</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
     <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff"> 
          <h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>ADMIN SIGN UP<img src="auk.jpg" style="width: 30px; float: left;"></strong>
</h5>
        <?php if (!empty($error_message)) {
  echo $error_message;
} ?>
  <?php if(!empty($success_message)){
    echo $success_message;}
    ?>
  
      <form action="" method="post"class="form-group">
      <h5><label>Usename:</label><input type="name" name="user_name" class="form-control" placeholder="username"></h5>
      <h5><label>Password</label><input type="password" name="passcode" class="form-control" placeholder="password"></h5>
      <h5><label>Confirm passcode</label><input type="password" name="passcode2" class="form-control" placeholder="password"></h5>
      <button class="btn btn-primary" name="submit">signup</button>
      <h5><a href = "admin.php">click here to sign in</h5>
        </form>
    </div>
  </div>
</div>
</body>
</html>

adminloggedin.php
<?php
session_start();
if (!isset($_SESSION['user_name'])) {
  header("location:index.php");
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="loggedin.php"><strong><img src="auk.jpg" style="width: 40px;"> Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
<div class="container fluid">
<div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff"> 
          <h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;"><strong>Admin :<?php echo $_SESSION['user_name']; ?><img src="auk.jpg" style="width: 30px; float: left;"></strong>
</h5> <br>
      <h5 style="text-align: center;"><a href="appliedaction.php" ><button type="button" class="btn btn-primary"><strong>Process Applied Id-Cards</strong></button></a></h5>
        <br>
           <h5 style="text-align: center;"><a href="lostaction.php">
      <button type="submit" name="lost" class="btn btn-danger"><strong>
       Process Lost Id-Cards</strong></button></h5>
  </div>
  </div>
</div>
</body>
</html>

appliedaction.php
<?php
session_start();
 if (!isset($_SESSION['user_name'])) {
   header('location:index.php');
 }
require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM apply";
$result = mysqli_query($connection,$sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="adminloggedin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>     <div class="container-fluid">
  <div class="alert alert-info" align="center" style="background-color:darkorange"><strong>Applied Id-Cards</strong></div>
    <div class="row">
        <div class="col-md-10 col-xs-12">
        <div class="panel panel-info">
          <div class="panel-heading"></div>
          <div class="panel-body">
      
  <table class="table" style="background-color:#FffEF4">
    <thead>
      <tr>
        <th style="text-align: center">id</th>
        <th style="text-align:center">Photo</th>
        <th style="text-align:center">Reg</th>
        <th style="text-align:center">Surname</th>
        <th style="text-align:center">othernames</th>
        <th style="text-align:center">college</th>
        <th style="text-align:center">department</th>
        <th style="text-align:center">course</th>
        <th style="text-align:center">kinno</th>
        <th style="text-align:center">Action</th>
        <th style="text-align:center">Delete</th>
      </tr>
    </thead>
    <?php
  while ($row = $result->fetch_assoc()):
  ?>
  <tbody>
  <tr>

    <td><?php echo $row["id"]; ?></td>
    <td><img src="<?php echo $row["image"]; ?>" width = "50px";></td>
    <td><?php echo $row["reg"];?></td>
    <td><?php echo $row["surname"]; ?></td>
    <td><?php echo $row["othernames"]; ?></td>
    <td><?php echo $row["college"]; ?></td>
    <td><?php echo $row["department"]; ?></td>
    <td><?php echo $row["course"]; ?></td>
    <td><?php echo $row["kinno"]; ?></td>
  
    <td><a href="appliedaction.php?action=<?php echo $row['id'];?>" 
      class = "btn btn-info"><img src="action.png" width="25px"></a></td>
          <td><a href="process.php?delete=<?php echo $row['id'];?>" 
      class = "btn btn-danger"><img src="delete.png" width="20px"></a></td>
      </tr>
</tbody>
<?php endwhile; ?>
  </table>
  </div>
</div>
</div>

  <?php
  function pre_r($array){
    echo '<pre>';
    print_r($array);
    echo '</pre>';
  }
  ?>
    <?php
    require_once 'process.php';
    ?> 
        <div class="col-md-2">
        <form action="gen.php" method="post">
       <input type="hidden" name="image" value="<?php if(!empty($image)){ echo $disp["image"];} ?>" placeholder="image" required class="form-control" readonly>
      <br>   
       <input type="text" name="reg" value="<?php if(!empty($reg)){ echo $disp["reg"];} ?>" placeholder="reg" required class="form-control" readonly>
      <br>
      <input type="text" name="surname" value="<?php if(!empty($surname)){ echo $disp["surname"];} ?>" placeholder = "Surname" required class="form-control" readonly>
      <br>
      <input type="hidden" name="othernames" value="<?php if(!empty($othernames)){ echo $disp["othernames"];} ?>" placeholder="othernames" required class="form-control" readonly>
      <input type="hidden" name="college" value="<?php if(!empty($college)){ echo $disp["college"];} ?>" placeholder="college" required class="form-control" readonly>
      <input type="hidden" name="department" value="<?php if(!empty($department)){ echo $disp["department"];} ?>" placeholder="department" required class="form-control" readonly>
      <input type="hidden" name="course" value="<?php if(!empty($course)){ echo $disp["course"];} ?>" placeholder="course" required class="form-control" readonly>
      <input type="hidden" name="kinno" value="<?php if(!empty($kinno)){ echo $disp["kinno"];} ?>" placeholder="kinno" required class="form-control" readonly>
      <button type="submit" name="submit" class="btn btn-primary">Generate ID</button>
    </form>
  </div>
      </div>
    </div>
</body>
</html>

apply.php
<?php
session_start();
 if (!isset($_SESSION['user_name'])) {
   header('location:index.php');
 }
require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM apply";
$result = mysqli_query($connection,$sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="adminloggedin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>     <div class="container-fluid">
  <div class="alert alert-info" align="center" style="background-color:darkorange"><strong>Applied Id-Cards</strong></div>
    <div class="row">
        <div class="col-md-10 col-xs-12">
        <div class="panel panel-info">
          <div class="panel-heading"></div>
          <div class="panel-body">
      
  <table class="table" style="background-color:#FffEF4">
    <thead>
      <tr>
        <th style="text-align: center">id</th>
        <th style="text-align:center">Photo</th>
        <th style="text-align:center">Reg</th>
        <th style="text-align:center">Surname</th>
        <th style="text-align:center">othernames</th>
        <th style="text-align:center">college</th>
        <th style="text-align:center">department</th>
        <th style="text-align:center">course</th>
        <th style="text-align:center">kinno</th>
        <th style="text-align:center">Action</th>
        <th style="text-align:center">Delete</th>
      </tr>
    </thead>
    <?php
  while ($row = $result->fetch_assoc()):
  ?>
  <tbody>
  <tr>

    <td><?php echo $row["id"]; ?></td>
    <td><img src="<?php echo $row["image"]; ?>" width = "50px";></td>
    <td><?php echo $row["reg"];?></td>
    <td><?php echo $row["surname"]; ?></td>
    <td><?php echo $row["othernames"]; ?></td>
    <td><?php echo $row["college"]; ?></td>
    <td><?php echo $row["department"]; ?></td>
    <td><?php echo $row["course"]; ?></td>
    <td><?php echo $row["kinno"]; ?></td>
  
    <td><a href="appliedaction.php?action=<?php echo $row['id'];?>" 
      class = "btn btn-info"><img src="action.png" width="25px"></a></td>
          <td><a href="process.php?delete=<?php echo $row['id'];?>" 
      class = "btn btn-danger"><img src="delete.png" width="20px"></a></td>
      </tr>
</tbody>
<?php endwhile; ?>
  </table>
  </div>
</div>
</div>

  <?php
  function pre_r($array){
    echo '<pre>';
    print_r($array);
    echo '</pre>';
  }
  ?>
    <?php
    require_once 'process.php';
    ?> 
        <div class="col-md-2">
        <form action="gen.php" method="post">
       <input type="hidden" name="image" value="<?php if(!empty($image)){ echo $disp["image"];} ?>" placeholder="image" required class="form-control" readonly>
      <br>   
       <input type="text" name="reg" value="<?php if(!empty($reg)){ echo $disp["reg"];} ?>" placeholder="reg" required class="form-control" readonly>
      <br>
      <input type="text" name="surname" value="<?php if(!empty($surname)){ echo $disp["surname"];} ?>" placeholder = "Surname" required class="form-control" readonly>
      <br>
      <input type="hidden" name="othernames" value="<?php if(!empty($othernames)){ echo $disp["othernames"];} ?>" placeholder="othernames" required class="form-control" readonly>
      <input type="hidden" name="college" value="<?php if(!empty($college)){ echo $disp["college"];} ?>" placeholder="college" required class="form-control" readonly>
      <input type="hidden" name="department" value="<?php if(!empty($department)){ echo $disp["department"];} ?>" placeholder="department" required class="form-control" readonly>
      <input type="hidden" name="course" value="<?php if(!empty($course)){ echo $disp["course"];} ?>" placeholder="course" required class="form-control" readonly>
      <input type="hidden" name="kinno" value="<?php if(!empty($kinno)){ echo $disp["kinno"];} ?>" placeholder="kinno" required class="form-control" readonly>
      <button type="submit" name="submit" class="btn btn-primary">Generate ID</button>
    </form>
  </div>
      </div>
    </div>
</body>
</html>

applyform.php

<?php
session_start();
if (!isset($_SESSION["reg"])) {
  header("location:loggedin.php");
}
include 'config.php';
if(isset($_POST['submit'])){
$reg = $_POST['reg'];
$surname = $_POST['surname'];
$othernames = $_POST['othernames'];
$college = $_POST['college'];
$department = $_POST['department'];
$course = $_POST['course'];
$kinno = $_POST['kinno'];

$select = "SELECT * FROM apply WHERE reg = '$reg'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
  echo "<script>alert('You have already made an Application!')</script>";
}
else{
  //code for image uploading
if($_FILES['f1']['name']){
   $fileinfo = @getimagesize($_FILES["file-input"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "png",
        "jpg",
        "jpeg"
    );
    
    // Get image file extension
    $file_extension = pathinfo($_FILES["f1"]["name"], PATHINFO_EXTENSION);
    if (! in_array($file_extension, $allowed_image_extension)) {
        $response = array(
            "type" => "error",
            "message" => "Upload valid images. Only PNG and JPEG are allowed."
        );
    }    // Validate image file size
    else if (($_FILES["f1"]["size"] > 5000000)) {
        $response = array(
            "type" => "error",
            "message" => "Image size exceeds 5MB"
        );
    }    // Validate image file dimension
    else if ($width > "300" || $height > "200") {
        $response = array(
            "type" => "error",
            "message" => "Image dimension should be within 300X200"
        );
    }else{
move_uploaded_file($_FILES['f1']['tmp_name'], "image/".$_FILES['f1']['name']);
$img="image/".$_FILES['f1']['name'];

$i="INSERT INTO apply(image,reg,surname,othernames,college,department,course,kinno)values('$img','$reg','$surname','$othernames','$college','$department','$course','$kinno')";
if(mysqli_query($connection, $i)){
echo "<script>alert('Application Successful!')</script>";
}
}
}
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="loggedin.php"><strong><img src="auk.jpg" style="width: 40px;"> Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
<br>
           <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-info" style="background-color: darkorange">ID CARD APPLICATION PAGE<img src="auk.jpg" style="width: 30px; float: left;">
</h5>
  <h5 style="text-align: center;"><a href="loggedin.php" >
      <button type="submit" class="btn btn-danger">
       Ok</button></h5>
</div>
</div>
</div>
</body>
</html>

config.php<?php
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";
$connection = mysqli_connect($host,$username,$password,$dbname);

// Check connection

if (mysqli_connect_errno())

{

 echo "Failed to connect to MySQL: " . mysqli_connect_error();

}

?>

forgot.php
<?php
session_start();
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

  $connection = mysqli_connect($host,$username,$password);
  $db = mysqli_select_db($connection,$dbname);
 $reg = ($_POST['reg']);
$select = "SELECT * FROM signup WHERE reg = '".$_POST["reg"]."'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
  $_SESSION['reg'] = $reg; 
  header('location:forgotprocess.php');
 }
  else{
    $error_message = "<div class = 'alert alert-danger'>Invalid Registration Number</div>";
     }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="index.php"><strong><img src="auk.jpg" style="width: 40px;"> Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="index.php"><strong>Student</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
       <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff"> 
          <h5 align="center" class="alert alert-info" style="background-color: darkorange; color: black;"><strong>STUDENT PASSWORD RESET<img src="auk.jpg" style="width: 30px; float: left;"></strong>
</h5>
          <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
      <form action="" method="post"class="form-group">
      <h6><label>Reg no:</label><input type="name" name="reg" class="form-control" placeholder="reg no" maxlength="15"></h6>
      <button class="btn btn-primary" name="submit">Next</button>
        </form>
    </div>
  </div>
</div>
</body>
</html>

forgot1.php

<?php
session_start();
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

  $connection = mysqli_connect($host,$username,$password);
  $db = mysqli_select_db($connection,$dbname);

 $user_name = ($_POST["user_name"]);
$select = "SELECT * FROM admin WHERE user_name = '".$_POST["user_name"]."'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
  $_SESSION['user_name'] = $user_name; 
  header('location:forgotprocess1.php');
 }
  else{
    $error_message = "<div class = 'alert alert-danger'>Invalid Username!</div>";
     }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="index.php"><img src="auk.jpg" style="width: 40px;"><strong>Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="admin.php"><strong>Admin</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
       <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff"> 
          <h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>ADMIN PASSWORD RESET<img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5>
          <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
      <form action="" method="post"class="form-group">
      <h6><label>Admin User Name:</label><input type="name" name="user_name" class="form-control" placeholder="Admin Username" maxlength="15"></h6>
      <button class="btn btn-primary" name="submit">Next</button>
        </form>
    </div>
  </div>
</div>
</body>
</html>

forgotprocess.php
<?php
session_start();
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

  $connection = mysqli_connect($host,$username,$password);
  $db = mysqli_select_db($connection,$dbname);

 $user_name = ($_POST["user_name"]);
$select = "SELECT * FROM admin WHERE user_name = '".$_POST["user_name"]."'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
  $_SESSION['user_name'] = $user_name; 
  header('location:forgotprocess1.php');
 }
  else{
    $error_message = "<div class = 'alert alert-danger'>Invalid Username!</div>";
     }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="index.php"><img src="auk.jpg" style="width: 40px;"><strong>Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="admin.php"><strong>Admin</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
       <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff"> 
          <h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>ADMIN PASSWORD RESET<img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5>
          <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
      <form action="" method="post"class="form-group">
      <h6><label>Admin User Name:</label><input type="name" name="user_name" class="form-control" placeholder="Admin Username" maxlength="15"></h6>
      <button class="btn btn-primary" name="submit">Next</button>
        </form>
    </div>
  </div>
</div>
</body>
</html>

forgotprocess1.php

<?php
session_start();
if (!isset($_SESSION['user_name'])) {
header("index.php");
}
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

$connection = mysqli_connect($host,$username,$password);
$db = mysqli_select_db($connection,$dbname);

if ($_POST["passcode"] != $_POST["passcode2"]) {
 $error_message = "<div class = 'alert alert-danger'>Passwords do not match!</div>";
} else {

  $sql = "UPDATE signup set user_name ='" . $_POST["user_name"] . "', passcode ='" . $_POST["passcode"] . "', passcode2 ='" . $_POST["passcode2"] . "' WHERE user_name='" . $_SESSION['user_name']  . "'";
 mysqli_query($connection, $sql);
$success_message = "<div class = 'alert alert-success'>Password reset Successful!</div>";
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
    <a class="navbar-brand" href="admin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="admin.php"><strong>Admin</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
     <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff"> 
          <h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>ADMIN PASSWORD RESET<img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5>
        <?php if (!empty($error_message)) {
  echo $error_message;
} ?>
  <?php if(!empty($success_message)){
    echo $success_message;}
    ?>
      <form action="" method="post"class="form-group">
      <h6><label>Enter Username:</label><input type="name" value="<?php echo $_SESSION['user_name'];?>"  name="user_name" class="form-control" placeholder="<?php echo $_SESSION['user_name'];?> " maxlength="15"readonly></h6>
      <h6><label>Choose new password</label><input type="password" name="passcode" class="form-control" placeholder="Enter new password"></h6>
      <h6><label>Confirm new password</label><input type="password" name="passcode2" class="form-control" placeholder="Confirm new password"></h6>
      <button class="btn btn-primary" name="submit">Reset</button>
      <h6><a href = "admin.php">back to sign in</h6>
        </form>
    </div>
  </div>
</div>
</body>
</html>

gen.php

<?php
session_start();
require_once 'config.php';
if (isset($_POST["submit"])) {
   $connection = new mysqli ("localhost","root","","std_idcard") or die($connection->error());
   $image = $_POST["image"];
   $reg = $_POST["reg"];
   $surname = $_POST["surname"];
   $othernames = $_POST["othernames"];
   $college = $_POST["college"];
   $department = $_POST["department"];
   $course = $_POST["course"];
   $kinno = $_POST["kinno"];   
   $query = "SELECT * FROM apply  WHERE reg = '$reg'";
   $result = mysqli_query($connection,$query);
   $rows = mysqli_num_rows ($result);
   if ($rows ==1) {
    $_SESSION["image"] = $image;
    $_SESSION["reg"] = $reg;
    $_SESSION["surname"] = $surname;
    $_SESSION["othernames"] = $othernames;
    $_SESSION["college"] = $college;
    $_SESSION["department"] = $department;
    $_SESSION["course"] = $course;
    $_SESSION["kinno"] = $kinno;
    }
    ?>
    <?php
    require_once "db.php";
   $select = "SELECT * FROM status  WHERE reg = '".$_SESSION['reg']."'";
   $display = mysqli_query($connection,$select);
   $row = mysqli_num_rows ($display);
   if ($row==1) {
      header("location:generate2.php");
    }else{
      $i="INSERT INTO status(image,reg,surname,othernames,college,department,course,kinno)values('$image','$reg','$surname','$othernames','$college','$department','$course','$kinno')";
mysqli_query($connection, $i);
      header('location:generate.php');  
        }
}
?>

gen2.php

<?php
session_start();
require_once 'config.php';
if (isset($_POST["submit"])) {
   $connection = new mysqli ("localhost","root","","std_idcard") or die($connection->error());
   $image = $_POST["image"];
   $reg = $_POST["reg"];
   $surname = $_POST["surname"];
   $othernames = $_POST["othernames"];
   $college = $_POST["college"];
   $department = $_POST["department"];
   $course = $_POST["course"];
   $kinno = $_POST["kinno"];   
   $query = "SELECT * FROM lost  WHERE reg = '$reg'";
   $result = mysqli_query($connection,$query);
   $rows = mysqli_num_rows ($result);
   if ($rows ==1) {
    $_SESSION["image"] = $image;
    $_SESSION["reg"] = $reg;
    $_SESSION["surname"] = $surname;
    $_SESSION["othernames"] = $othernames;
    $_SESSION["college"] = $college;
    $_SESSION["department"] = $department;
    $_SESSION["course"] = $course;
    $_SESSION["kinno"] = $kinno;
    }
    ?>
    <?php
    require_once "db.php";
   $select = "SELECT * FROM status2  WHERE reg = '".$_SESSION['reg']."'";
   $display = mysqli_query($connection,$select);
   $row = mysqli_num_rows ($display);
   if ($row==1) {
      header("location:generate4.php");
    }else{
      $i="INSERT INTO status2 (image,reg,surname,othernames,college,department,course,kinno)values('$image','$reg','$surname','$othernames','$college','$department','$course','$kinno')";
mysqli_query($connection, $i);
      header('location:generate3.php');  
        }
}
?>

generate.php

<?php
session_start();
 if (!isset($_SESSION['user_name'])) {
   header('location:index.php');
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="adminloggedin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>

    <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?> 
<br><div class="container">
      <div class="row justify-content-center">
        <div class="col-md-0 ">
          <div class="thumbnail">
            <div  class="col-md-0">
            <div class="alert alert-success"><strong>Id-Card Processed!</strong></div>
          </div>              <div class="card mb-3 box-shadow" style="background-color: white;
              width: 305px; height: 190px" >
                  <div class="card-body" style="width:smaller; height: smaller;">
<img src="auk.jpg" style="width: 30px; float: left;">
<h6><small><strong style="color: red">AL QALAM UNIVERSITY KATSINA</strong></small></h6>
  <img src='<?php echo $_SESSION["image"]; ?>' style="
    width: 40px;
    height: 50px;
    background-color: #FFF; float: right;">
    <p><small><h6 >NAME: <small> <?php echo $_SESSION["surname"];?>
    <?php echo $_SESSION["othernames"];?></small></h6>
    REG:<?php echo $_SESSION["reg"];?>
    <br>
    DEPT: <?php echo $_SESSION["department"];?>
    <br>
    NEXT OF KIN NO : <?php echo $_SESSION["kinno"];?>
    <p style="background-color: red;color: white;">STUDENT ID CARD <small style="float: right;">Valid  till 2025</small> </p>
  <div class="d-flex justify-content-between align-items-center">
  </div>
</small>
</p>
</div>
</div>
<br>
<br>
   <div class="card mb-3 box-shadow" style="background-color: white;
              width: 305px; height: 190px" >
              <div class="card-body" style="width:smaller; height: smaller;">
<small><img src="auk.jpg" style="width: 40px; float: right;">
   <h6><small>This is to certify that the bearer whose picture and name appear
    on this card is a bonafide student of: <br>
  <strong align = "center">AL-QALAM UNIVERSITY,KATSINA</strong><img src="qrcode.jpg" style="width: 80px; float: right;"><br>
  <small>P.M.B 2137, Dutsinma Road, Katsina</small>
  <br>
  Please if found, please return to the <br>
  overleaf address nearest police station.</small></h6>
</div></small>
</div>
</div>
<div><button class="btn btn-success" onClick="window.print()">Print this page
</button></div>
</div>
</div>
</body>
</html>

generate2.php

<?php
session_start();
 if (!isset($_SESSION['user_name'])) {
   header('location:index.php');
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="adminloggedin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>

    <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?> 
<br><div class="container">
      <div class="row justify-content-center">
        <div class="col-md-0 ">
          <div class="thumbnail">
            <div  class="col-md-0">
            <div class="alert alert-danger"><strong>Id-Card Already Processed!</strong></div>
          </div>              <div class="card mb-3 box-shadow" style="background-color: white;
              width: 305px; height: 190px" >
                  <div class="card-body" style="width:smaller; height: smaller;">
<img src="auk.jpg" style="width: 30px; float: left;">
<h6><small><strong style="color: red">AL QALAM UNIVERSITY KATSINA</strong></small></h6>
  <img src='<?php echo $_SESSION["image"]; ?>' style="
    width: 40px;
    height: 50px;
    background-color: #FFF; float: right;">
    <p><small><h6 >NAME: <small> <?php echo $_SESSION["surname"];?>
    <?php echo $_SESSION["othernames"];?></small></h6>
    REG:<?php echo $_SESSION["reg"];?>
    <br>
    DEPT: <?php echo $_SESSION["department"];?>
    <br>
    NEXT OF KIN NO : <?php echo $_SESSION["kinno"];?>
    <p style="background-color: red;color: white;">STUDENT ID CARD <small style="float: right;">Valid  till 2025</small> </p>
  <div class="d-flex justify-content-between align-items-center">
  </div>
</small>
</p>
</div>
</div>
<br>
<br>
   <div class="card mb-3 box-shadow" style="background-color: white;
              width: 305px; height: 190px" >
              <div class="card-body" style="width:smaller; height: smaller;">
<small><img src="auk.jpg" style="width: 40px; float: right;">
   <h6><small>This is to certify that the bearer whose picture and name appear
    on this card is a bonafide student of: <br>
  <strong align = "center">AL-QALAM UNIVERSITY,KATSINA</strong><img src="qrcode.jpg" style="width: 80px; float: right;"><br>
  <small>P.M.B 2137, Dutsinma Road, Katsina</small>
  <br>
  Please if found, please return to the <br>
  overleaf address nearest police station.</small></h6>
</div></small>
</div>
</div>
<div><button class="btn btn-success" onClick="window.print()">Print this page
</button></div>
</div>
</div>
</body>
</html>

generate3.php

<?php
session_start();
 if (!isset($_SESSION['user_name'])) {
   header('location:index.php');
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="adminloggedin.php"><img src="auk.jpg" style="width: 40px;">Student id-card</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>

    <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?> 
<br>  <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-0 ">
          <div class="thumbnail">
            <div  class="col-md-0">
            <div class="alert alert-danger"><strong>Id-Card Already Processed!</strong></div>
          </div>
              <div class="card mb-3 box-shadow" style="background-color: white;
              width: 305px; height: 190px" >
                  <div class="card-body" style="width:smaller; height: smaller;">
<img src="auk.jpg" style="width: 30px; float: left;">
<h6><small><strong style="color: red">AL QALAM UNIVERSITY KATSINA</strong></small></h6>
  <img src='<?php echo $_SESSION["image"]; ?>' style="
    width: 40px;
    height: 50px;
    background-color: #FFF; float: right;">
    <p><small><h6 >NAME: <small> <?php echo $_SESSION["surname"];?>
    <?php echo $_SESSION["othernames"];?></small></h6>
    REG:<?php echo $_SESSION["reg"];?>
    <br>
    DEPT: <?php echo $_SESSION["department"];?>
    <br>
    NEXT OF KIN NO : <?php echo $_SESSION["kinno"];?>
    <p style="background-color: red;color: white;">STUDENT ID CARD <small style="float: right;">Valid  till 2025</small> </p>
  <div class="d-flex justify-content-between align-items-center">
  </div>
</small>
</p>
</div>
</div>
<br>
<br>
   <div class="card mb-3 box-shadow" style="background-color: white;
              width: 305px; height: 190px" >
              <div class="card-body" style="width:smaller; height: smaller;">
<small><img src="auk.jpg" style="width: 40px; float: right;">
   <h6><small>This is to certify that the bearer whose picture and name appear
    on this card is a bonafide student of: <br>
  <strong align = "center">AL-QALAM UNIVERSITY,KATSINA</strong><img src="qrcode.jpg" style="width: 80px; float: right;"><br>
  <small>P.M.B 2137, Dutsinma Road, Katsina</small>
  <br>
  Please if found, please return to the <br>
  overleaf address nearest police station.</small></h6>
</div></small>
</div>
</div>
<div><button class="btn btn-success" onClick="window.print()">Print this page
</button></div>
</div>
</div>
</body>
</html>

generate4.php

<?php
session_start();
 if (!isset($_SESSION['user_name'])) {
   header('location:index.php');
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="adminloggedin.php"><img src="auk.jpg" style="width: 40px;">Student id-card</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>

    <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?> 
<br>  <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-0 ">
          <div class="thumbnail">
            <div  class="col-md-0">
            <div class="alert alert-danger"><strong>Id-Card Already Processed!</strong></div>
          </div>
              <div class="card mb-3 box-shadow" style="background-color: white;
              width: 305px; height: 190px" >
                  <div class="card-body" style="width:smaller; height: smaller;">
<img src="auk.jpg" style="width: 30px; float: left;">
<h6><small><strong style="color: red">AL QALAM UNIVERSITY KATSINA</strong></small></h6>
  <img src='<?php echo $_SESSION["image"]; ?>' style="
    width: 40px;
    height: 50px;
    background-color: #FFF; float: right;">
    <p><small><h6 >NAME: <small> <?php echo $_SESSION["surname"];?>
    <?php echo $_SESSION["othernames"];?></small></h6>
    REG:<?php echo $_SESSION["reg"];?>
    <br>
    DEPT: <?php echo $_SESSION["department"];?>
    <br>
    NEXT OF KIN NO : <?php echo $_SESSION["kinno"];?>
    <p style="background-color: red;color: white;">STUDENT ID CARD <small style="float: right;">Valid  till 2025</small> </p>
  <div class="d-flex justify-content-between align-items-center">
  </div>
</small>
</p>
</div>
</div>
<br>
<br>
   <div class="card mb-3 box-shadow" style="background-color: white;
              width: 305px; height: 190px" >
              <div class="card-body" style="width:smaller; height: smaller;">
<small><img src="auk.jpg" style="width: 40px; float: right;">
   <h6><small>This is to certify that the bearer whose picture and name appear
    on this card is a bonafide student of: <br>
  <strong align = "center">AL-QALAM UNIVERSITY,KATSINA</strong><img src="qrcode.jpg" style="width: 80px; float: right;"><br>
  <small>P.M.B 2137, Dutsinma Road, Katsina</small>
  <br>
  Please if found, please return to the <br>
  overleaf address nearest police station.</small></h6>
</div></small>
</div>
</div>
<div><button class="btn btn-success" onClick="window.print()">Print this page
</button></div>
</div>
</div>
</body>
</html>

index.php

<?php
session_start();
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

  $connection = mysqli_connect($host,$username,$password);
  $db = mysqli_select_db($connection,$dbname);
 $reg = ($_POST['reg']);
 $passcode = ($_POST['passcode']);
$select = "SELECT * FROM signup WHERE reg = '".$_POST["reg"]."' && passcode = '".$_POST["passcode"]."'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
  $_SESSION['reg'] = $reg; 
  header('location:loggedin.php');
 }
  else{
    $error_message = "<div class = 'alert alert-danger'>Invalid Registration Number or password</div>";
     }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="index.php"><img src="auk.jpg" style="width: 40px;"><strong>Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="admin.php"><strong>Admin</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
       <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff"> 
          <h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>SIGN IN PAGE<img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5>
          <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
      <form action="" method="post"class="form-group">
      <h6><label>Reg no:</label><input type="name" name="reg" class="form-control" placeholder="reg no" maxlength="15" required></h6>
      <h6><label>Password</label><input type="password" name="passcode" class="form-control" placeholder="password" required></h6>
      <button class="btn btn-primary" name="submit">Login</button>
      <br>
      <a href = "signup.php">click here to sign up</a>
      <br>
      <a href = "forgot.php">Forgot Password?</a>
        </form>
    </div>
  </div>
</div>
</body>
</html>

loggedin.php

<?php
session_start();
if (!isset($_SESSION['reg'])) {
  header("location:index.php");
}
?>
<?php
if (isset($_POST["check"])) {
  require_once "db.php";
   $select = "SELECT * FROM status  WHERE reg = '".$_SESSION['reg']."'";
   $display = mysqli_query($connection,$select);
   $row = mysqli_num_rows ($display);
   if ($row==1) {
      $success_message = "<div class = 'alert alert-success'>Your id card is ready for collection, thank you!</div>";
    }else{
    $error_message = "<div class = 'alert alert-danger'>Your id card is not yet ready for collection, thank you!</div>";
  }
}


if (isset($_POST["lost"])) {
  require_once "db.php";
   $select = "SELECT * FROM apply  WHERE reg = '".$_SESSION['reg']."'";
   $display = mysqli_query($connection,$select);
   $row = mysqli_num_rows ($display);
   if ($row==1) {
    header("location:lost.php");
    }
    else{
    $error_message = "<div class = 'alert alert-danger'>Apply for Id-Card,thank you!</div>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
<a class="navbar-brand" href="loggedin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
<div class="container fluid">
<div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff"> 
          <h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong><?php echo $_SESSION['reg']; ?><img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5> <br>
 <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?>
      <h5 style="text-align: center;"><a href="apply.php" ><button type="button" class="btn btn-primary">Apply for Std Id-Card</button></a></h5>
        <br>
           <form action="" method="post">
           <h5 style="text-align: center;">
      <button type="submit" name="check" class="btn btn-success">
       Check for availability</button></h5>
     </form>
     <br>
           <h5 style="text-align: center;"><a href="lostid.php" >
      <button type="submit" class="btn btn-danger">
       Lost Id-Card Enquiry</button></h5>
          </div>
  </div>
</div>
</body>
</html>

logout.php

<?php
session_start();
session_destroy();
header('location:index.php');
?>

lostaction.php

<?php
session_start();
 if (!isset($_SESSION['user_name'])) {
   header('location:index.php');
 }
require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM lost";
$result = mysqli_query($connection,$sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="adminloggedin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width:25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>     <div class="container-fluid">
  <div class="alert alert-success" align="center"  style="background-color:darkorange;"><strong>Process Lost Id-Cards</strong></div>
    <div class="row">
        <div class="col-md-10 col-xs-12">
        <div class="panel panel-info">
          <div class="panel-heading">Table</div>
          <div class="panel-body">
      
  <table class="table" style="background-color:#FffEF4">
    <thead>
      <tr>
        <th style="text-align: center">id</th>
        <th style="text-align:center">Photo</th>
        <th style="text-align:center">Reg</th>
        <th style="text-align:center">Surname</th>
        <th style="text-align:center">othernames</th>
        <th style="text-align:center">college</th>
        <th style="text-align:center">department</th>
        <th style="text-align:center">course</th>
        <th style="text-align:center">kinno</th>
        <th style="text-align:center">Action</th>
        <th style="text-align:center">Delete</th>
      </tr>
    </thead>
    <?php
  while ($row = $result->fetch_assoc()):
  ?>
  <tbody>
  <tr>

    <td><?php echo $row["id"]; ?></td>
    <td><img src="<?php echo $row["image"]; ?>" width = "50px";></td>
    <td><?php echo $row["reg"];?></td>
    <td><?php echo $row["surname"]; ?></td>
    <td><?php echo $row["othernames"]; ?></td>
    <td><?php echo $row["college"]; ?></td>
    <td><?php echo $row["department"]; ?></td>
    <td><?php echo $row["course"]; ?></td>
    <td><?php echo $row["kinno"]; ?></td>
  
    <td><a href="lostaction.php?action=<?php echo $row['id'];?>" 
      class = "btn btn-info"><img src="action.png" width="25px"></a></td>
          <td><a href="process1.php?delete=<?php echo $row['id'];?>" 
      class = "btn btn-danger"><img src="delete.png" width="20px"></a></td>
      </tr>
</tbody>
<?php endwhile; ?>
  </table>
  </div>
</div>
</div>

  <?php
  function pre_r($array){
    echo '<pre>';
    print_r($array);
    echo '</pre>';
  }
  ?>
    <?php
    require_once 'process1.php';
    ?> 
        <div class="col-md-2">
        <form action="gen2.php" method="post">
       <input type="hidden" name="image" value="<?php if(!empty($image)){ echo $disp["image"];} ?>" placeholder="image" required class="form-control" readonly>
      <br>   
       <input type="text" name="reg" value="<?php if(!empty($reg)){ echo $disp["reg"];} ?>" placeholder="reg" required class="form-control" readonly>
      <br>
      <input type="text" name="surname" value="<?php if(!empty($surname)){ echo $disp["surname"];} ?>" placeholder = "Surname" required class="form-control" readonly>
      <br>
      <input type="hidden" name="othernames" value="<?php if(!empty($othernames)){ echo $disp["othernames"];} ?>" placeholder="othernames" required class="form-control" readonly>
      <input type="hidden" name="college" value="<?php if(!empty($college)){ echo $disp["college"];} ?>" placeholder="college" required class="form-control" readonly>
      <input type="hidden" name="department" value="<?php if(!empty($department)){ echo $disp["department"];} ?>" placeholder="department" required class="form-control" readonly>
      <input type="hidden" name="course" value="<?php if(!empty($course)){ echo $disp["course"];} ?>" placeholder="course" required class="form-control" readonly>
      <input type="hidden" name="kinno" value="<?php if(!empty($kinno)){ echo $disp["kinno"];} ?>" placeholder="kinno" required class="form-control" readonly>
      <button type="submit" name="submit" class="btn btn-primary">Generate ID</button>
    </form>
  </div>
      </div>
    </div>
</body>
</html>

lostid.php

<?php
session_start();
if (!isset($_SESSION["reg"])) {
  header("location:index.php");
}
  require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM apply WHERE reg = '".$_SESSION['reg']."'";
$result = mysqli_query($connection,$sql);
if (isset($_POST["check"])) {
  require_once "db.php";
   $select = "SELECT * FROM status2  WHERE reg = '".$_SESSION['reg']."'";
   $display = mysqli_query($connection,$select);
   $row = mysqli_num_rows ($display);
   if ($row==1) {
      $success_message = "<div class = 'alert alert-success'>Your lost id card is ready for collection, thank you!</div>";
    }else{
    $error_message = "<div class = 'alert alert-danger'>Your lost id card is not yet ready for collection, thank you!</div>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="loggedin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
       <br>
           <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>LOST ID CARD APPLICATION PAGE<img src="auk.jpg" style="width: 30px; float: left;"></strong>
</h5>
        <?php 
        if (!empty($error_message)) {
          echo $error_message;
        } 
        if (!empty($success_message)) {
          echo $success_message;
        } 
               ?>
               <form action="" method="post">
           <h5 style="text-align: center;">
      <button type="submit" name="check" class="btn btn-success">
       Check for lost id-card availability</button></h5>
     </form>
      <form action="" enctype="multipart/form-data" method="post"class="form-group">
        <?php while ($row = $result->fetch_assoc()):?>
        <input type="text" name="image" class="form-control"  placeholder="<?php echo  $row['image'];?>" value = "<?php echo  $row['image'];?>"  required readonly>
      <h5><label>Reg NO:</label><input type="text" name="reg" class="form-control" placeholder="<?php echo  $_SESSION['reg'];?>" value = "<?php echo  $_SESSION['reg'];?>"  required readonly></h5>
      <h5><label>Surname:</label><input type="text" name="surname" class="form-control"  placeholder="<?php echo  $row['surname'];?>" value = "<?php echo  $row['surname'];?>"  required readonly ></h5>
      <h5><label>Othernames</label><input type="text" name="othernames" class="form-control"  placeholder="<?php echo  $row['othernames'];?>" value = "<?php echo  $row['othernames'];?>"  required readonly></h5>
      <h5><label>College:</label><input type="text" name="college" class="form-control" placeholder="<?php echo  $row['college'];?>" value = "<?php echo  $row['college'];?>"  required readonly></h5>
      <h5><label>Department</label><input type="text" name="department" class="form-control" placeholder="<?php echo  $row['department'];?>" value = "<?php echo  $row['department'];?>"  required readonly></h5>
      <h5><label>Course:</label><input type="text" name="course" class="form-control" placeholder="<?php echo  $row['course'];?>" value = "<?php echo  $row['course'];?>"  required readonly></h5>    
      <h5><label>Next of kin no:</label><input type="number" name="kinno" class="form-control" placeholder="<?php echo  $row['kinno'];?>" value = "<?php echo  $row['kinno'];?>"  required readonly></h5>
      <?php endwhile; ?>  
      <button class="btn btn-primary" name="submit">Apply</button>
      <br>
      <h5><a href = "loggedin.php">back</h5>
        </form>
    </div>
  </div>
</div>
</body>
</html>

<?php
if(isset($_POST['submit'])){
require_once("db.php");
$image = $_POST['image'];
$reg = $_POST['reg'];
$surname = $_POST['surname'];
$othernames = $_POST['othernames'];
$college = $_POST['college'];
$department = $_POST['department'];
$course = $_POST['course'];
$kinno = $_POST['kinno'];

$select = "SELECT * FROM lost WHERE reg = '$reg'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
  echo '<script>alert("You have already made a lost id-card Application!")</script></div>';
}else{
$i="INSERT INTO lost(image,reg,surname,othernames,college,department,course,kinno)values('$image','$reg','$surname','$othernames','$college','$department','$course','$kinno')";
mysqli_query($connection, $i);
  echo '<script>alert("Lost Id-Card Application Successful!")</script></div>';

}
}
?>

process.php

<?php
require_once 'config.php';
if (isset($_GET['action'])) {
$id = $_GET['action'];
$connection = new mysqli ("localhost","root","","std_idcard") or die($connection->error());
$result = $connection->query("SELECT * FROM apply WHERE id = $id");
if (mysqli_num_rows($result)==1){
  $disp = $result->fetch_array();
  $image = $disp["image"];
  $reg = $disp["reg"];
  $surname = $disp["surname"]; 
    $othernames = $disp["othernames"];
    $college = $disp["college"];
    $department = $disp["department"];
    $course = $disp["course"];
    $kinno = $disp["kinno"];
}
}

if (isset($_GET['delete'])) {
$id = $_GET['delete'];
$connection = new mysqli ("localhost","root","","std_idcard") or die($connection->error());
$result = $connection->query("DELETE FROM apply WHERE id = $id");
header("location:appliedaction.php");
}
?>

process1.php

<?php
require_once 'config.php';
if (isset($_GET['action'])) {
$id = $_GET['action'];
$connection = new mysqli ("localhost","root","","std_idcard") or die($connection->error());
$result = $connection->query("SELECT * FROM lost WHERE id = $id");
if (mysqli_num_rows($result)==1){
  $disp = $result->fetch_array();
  $image = $disp["image"];
  $reg = $disp["reg"];
  $surname = $disp["surname"]; 
    $othernames = $disp["othernames"];
    $college = $disp["college"];
    $department = $disp["department"];
    $course = $disp["course"];
    $kinno = $disp["kinno"];
}
}

if (isset($_GET['delete'])) {
$id = $_GET['delete'];
$connection = new mysqli ("localhost","root","","std_idcard") or die($connection->error());
$result = $connection->query("DELETE FROM lost WHERE id = $id");
header("location:lostaction.php");
}
?>

signup.php

<?php
session_start();
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";
  $connection = mysqli_connect($host,$username,$password);
  $db = mysqli_select_db($connection,$dbname);
  $course = ($_POST['course']);
$select = "SELECT * FROM colleges WHERE course = '".$_POST['course']."'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
  $_SESSION['course'] = $course;
  if ($course == "Comp. Science" ) {
    header("location:signupp.php");
 }
 else if ($course == "Mathematics" ) {
    header("location:signupp1.php");
 }
 else if ($course == "Biology" ) {
    header("location:signupp2.php");
 }
 else if ($course == "Chemistry" ) {
    header("location:signupp3.php");
 }
  else if ($course == "Physics") {
    header("location:signupp4.php");
 }
}
  else{
   $success_message = "<div class = 'alert alert-success'>Invalid Course!</div>";     
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <strong><a class="navbar-brand" href="index.php"><img src="auk.jpg" style="width: 40px;"> Student id-card</a></strong>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="index.php"><strong>Student</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav><br>
       <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>SIGN UP PAGE<img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5>
<form action="" method="post"class="form-group">
 <label for="course-select">course:</label>
      <select type = "text" name="course" id="pet-select" class="form-control" required>
    <option value="">--Please select your course--</option>
    <option value="Comp. Science">Comp. Science</option>
    <option value="Mathematics">Mathematics</option>
    <option value="Biology">Biology</option>
    <option value="Chemistry">Chemistry</option>
    <option value="Physics">Physics</option>
  </select>
<br>
        <button class="btn btn-primary" name="submit">Next</button>
      <h6><a href = "index.php">back to sign in</h6>
        </form>
    </div>
  </div>
</div>
</body>
</html>

signupp.php

<?php
session_start();
if (!isset($_SESSION['course'])) {
  header('location:signup.php');
}
require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM colleges WHERE course = '".$_SESSION['course']."'";
$result = mysqli_query($connection,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <strong><a class="navbar-brand" href="index.php"><img src="auk.jpg" style="width: 40px;"> Student id-card</a></strong>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="index.php"><strong>Student</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav><br>
       <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>SIGN UP PAGE<img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5>
    <?php
  while ($row = $result->fetch_assoc()):
  ?>
    <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?> 
<form action="" method="post"class="form-group">
       <label for="college">College:</label>
      <input type = "text" name="college" value="<?php echo $row["college"];?>" placeholder ="<?php echo $row["college"];?>" class="form-control" readonly required>
       <label for="department">Department:</label>
      <input type = "text" name="department" value="<?php echo $row["department"];?>" placeholder ="<?php echo $row["department"];?>" class="form-control" readonly required>
       <label for="course">Course:</label>
      <input type = "text" name="course" value="<?php echo $_SESSION["course"];?>" placeholder ="<?php echo $_SESSION["course"];?>" max="15" class="form-control" readonly required>
      
      <h6><label>Reg no:</label><input type="name" name="reg" class="form-control" maxlength="15" minlength="15" placeholder="reg no"></h6>
      <h6><label>Password</label><input type="password" name="passcode" class="form-control" placeholder="password"></h6>
      <h6><label>Confirm Password</label><input type="password" name="passcode2" class="form-control" placeholder="confirm password"></h6>
        <button class="btn btn-primary" name="submit">Sign Up</button>
      <h6><a href = "index.php">back to sign in</h6>
       <?php endwhile; ?>
        </form>
    </div>
  </div>
</div>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

  $connection = mysqli_connect($host,$username,$password);
  $db = mysqli_select_db($connection,$dbname);

for ($i=16; $i<=20  ; $i++) { 
  for ($k=1000; $k<=1200; $k++){
$dept_comp[$i][$k] = "Nas/Csc/".$i."/".$k;
}
}
  $college = ($_POST['college']);
  $department = ($_POST['department']);
  $course = ($_POST['course']);
 $reg = ($_POST['reg']);
 $passcode = ($_POST['passcode']);
 $passcode2 = ($_POST['passcode2']);
$reglength = strlen($reg);

 if ($reg <= "Nas/Csc/16" or $reg <= "Nas/Csc/17" or $reg <= "Nas/Csc/18"
 or $reg <= "Nas/Csc/19" or $reg <= "Nas/Csc/20" or $reg <= "Nas/Csc/21" && $reglength<=15){
  if ($passcode!= $passcode2) {
   echo "<script>alert('Passwords do not match!')</script>";
}
else{
$select = "SELECT * FROM signup WHERE reg = '".$_POST["reg"]."'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
   echo "<script>alert('Record already exists!')</script>";
 }
  else{
  $insert = "INSERT INTO signup (college,department,course,reg,passcode,passcode2) VALUES('".$_POST["college"]."','".$_POST["department"]."','".$_POST["course"]."','".$_POST["reg"]."',
'".$_POST["passcode"]."','".$_POST["passcode2"]."')";
   mysqli_query($connection,$insert);
   echo "<script>alert('Record Successfully Inserted!')</script>";     
  }
}
}
else{
  echo "<script>alert('Invalid Registration Number!')</script>";
}
}  
?>

signupp1.php

<?php
session_start();
if (!isset($_SESSION['course'])) {
  header('location:signup.php');
}
require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM colleges WHERE course = '".$_SESSION['course']."'";
$result = mysqli_query($connection,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <strong><a class="navbar-brand" href="index.php"><img src="auk.jpg" style="width: 40px;"> Student id-card</a></strong>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="index.php"><strong>Student</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
       <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>SIGN UP PAGE<img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5>
    <?php
  while ($row = $result->fetch_assoc()):
  ?>
    <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?> 
<form action="" method="post"class="form-group">
       <label for="college">College:</label>
      <input type = "text" name="college" value="<?php echo $row["college"];?>" placeholder ="<?php echo $row["college"];?>" class="form-control" readonly required>
       <label for="department">Department:</label>
      <input type = "text" name="department" value="<?php echo $row["department"];?>" placeholder ="<?php echo $row["department"];?>" class="form-control" readonly required>
       <label for="course">Course:</label>
      <input type = "text" name="course" value="<?php echo $_SESSION["course"];?>" placeholder ="<?php echo $_SESSION["course"];?>" max="15" class="form-control" readonly required>
      
      <h6><label>Reg no:</label><input type="name" name="reg" class="form-control" maxlength="15" minlength="15" placeholder="reg no"></h6>
      <h6><label>Password</label><input type="password" name="passcode" class="form-control" placeholder="password"></h6>
      <h6><label>Confirm Password</label><input type="password" name="passcode2" class="form-control" placeholder="confirm password"></h6>
        <button class="btn btn-primary" name="submit">Sign Up</button>
      <h6><a href = "index.php">back to sign in</h6>
       <?php endwhile; ?>
        </form>
    </div>
  </div>
</div>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

  $connection = mysqli_connect($host,$username,$password);
  $db = mysqli_select_db($connection,$dbname);

for ($i=16; $i<=20  ; $i++) { 
  for ($k=1000; $k<=1200; $k++){
$dept_comp[$i][$k] = "Nas/Mth/".$i."/".$k;
}
}
  $college = ($_POST['college']);
  $department = ($_POST['department']);
  $course = ($_POST['course']);
 $reg = ($_POST['reg']);
 $passcode = ($_POST['passcode']);
 $passcode2 = ($_POST['passcode2']);
$reglength = strlen($reg);

 if ($reg <= "Nas/Mth/16" or $reg <= "Nas/Mth/17" or $reg <= "Nas/Mth/18"
 or $reg <= "Nas/Mth/19" or $reg <= "Nas/Mth/20" or $reg <= "Nas/Mth/21" && $reglength<=15){
  if ($passcode!= $passcode2) {
   echo "<script>alert('Passwords do not match!')</script>";
}
else{
$select = "SELECT * FROM signup WHERE reg = '".$_POST["reg"]."'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
   echo "<script>alert('Record already exists!')</script>";
 }
  else{
  $insert = "INSERT INTO signup (college,department,course,reg,passcode,passcode2) VALUES('".$_POST["college"]."','".$_POST["department"]."','".$_POST["course"]."','".$_POST["reg"]."',
'".$_POST["passcode"]."','".$_POST["passcode2"]."')";
   mysqli_query($connection,$insert);
   echo "<script>alert('Record Successfully Inserted!')</script>";     
  }
}
}
else{
  echo "<script>alert('Invalid Registration Number!')</script>";
}
}  
?>

signupp2.php

<?php
session_start();
if (!isset($_SESSION['course'])) {
  header('location:signup.php');
}
require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM colleges WHERE course = '".$_SESSION['course']."'";
$result = mysqli_query($connection,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <strong><a class="navbar-brand" href="index.php"><img src="auk.jpg" style="width: 40px;"> Student id-card</a></strong>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="index.php"><strong>Student</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
       <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>SIGN UP PAGE<img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5>
    <?php
  while ($row = $result->fetch_assoc()):
  ?>
    <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?> 
<form action="" method="post"class="form-group">
       <label for="college">College:</label>
      <input type = "text" name="college" value="<?php echo $row["college"];?>" placeholder ="<?php echo $row["college"];?>" class="form-control" readonly required>
       <label for="department">Department:</label>
      <input type = "text" name="department" value="<?php echo $row["department"];?>" placeholder ="<?php echo $row["department"];?>" class="form-control" readonly required>
       <label for="course">Course:</label>
      <input type = "text" name="course" value="<?php echo $_SESSION["course"];?>" placeholder ="<?php echo $_SESSION["course"];?>" max="15" class="form-control" readonly required>
      
      <h6><label>Reg no:</label><input type="name" name="reg" class="form-control" maxlength="15" minlength="15" placeholder="reg no"></h6>
      <h6><label>Password</label><input type="password" name="passcode" class="form-control" placeholder="password"></h6>
      <h6><label>Confirm Password</label><input type="password" name="passcode2" class="form-control" placeholder="confirm password"></h6>
        <button class="btn btn-primary" name="submit">Sign Up</button>
      <h6><a href = "index.php">back to sign in</h6>
       <?php endwhile; ?>
        </form>
    </div>
  </div>
</div>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

  $connection = mysqli_connect($host,$username,$password);
  $db = mysqli_select_db($connection,$dbname);

for ($i=16; $i<=20  ; $i++) { 
  for ($k=1000; $k<=1200; $k++){
$dept_comp[$i][$k] = "Nas/Bio/".$i."/".$k;
}
}
  $college = ($_POST['college']);
  $department = ($_POST['department']);
  $course = ($_POST['course']);
 $reg = ($_POST['reg']);
 $passcode = ($_POST['passcode']);
 $passcode2 = ($_POST['passcode2']);
$reglength = strlen($reg);

 if ($reg <= "Nas/Bio/16" or $reg <= "Nas/Bio/17" or $reg <= "Nas/Bio/18"
 or $reg <= "Nas/Bio/19" or $reg <= "Nas/Bio/20" or $reg <= "Nas/Bio/21" && $reglength<=15){
  if ($passcode!= $passcode2) {
   echo "<script>alert('Passwords do not match!')</script>";
}
else{
$select = "SELECT * FROM signup WHERE reg = '".$_POST["reg"]."'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
   echo "<script>alert('Record already exists!')</script>";
 }
  else{
  $insert = "INSERT INTO signup (college,department,course,reg,passcode,passcode2) VALUES('".$_POST["college"]."','".$_POST["department"]."','".$_POST["course"]."','".$_POST["reg"]."',
'".$_POST["passcode"]."','".$_POST["passcode2"]."')";
   mysqli_query($connection,$insert);
   echo "<script>alert('Record Successfully Inserted!')</script>";     
  }
}
}
else{
  echo "<script>alert('Invalid Registration Number!')</script>";
}
}  
?>

signupp3.php

<?php
session_start();
if (!isset($_SESSION['course'])) {
  header('location:signup.php');
}
require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM colleges WHERE course = '".$_SESSION['course']."'";
$result = mysqli_query($connection,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <strong><a class="navbar-brand" href="index.php"><img src="auk.jpg" style="width: 40px;"> Student id-card</a></strong>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="index.php"><strong>Student</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
       <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>SIGN UP PAGE<img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5>
    <?php
  while ($row = $result->fetch_assoc()):
  ?>
    <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?> 
<form action="" method="post"class="form-group">
       <label for="college">College:</label>
      <input type = "text" name="college" value="<?php echo $row["college"];?>" placeholder ="<?php echo $row["college"];?>" class="form-control" readonly required>
       <label for="department">Department:</label>
      <input type = "text" name="department" value="<?php echo $row["department"];?>" placeholder ="<?php echo $row["department"];?>" class="form-control" readonly required>
       <label for="course">Course:</label>
      <input type = "text" name="course" value="<?php echo $_SESSION["course"];?>" placeholder ="<?php echo $_SESSION["course"];?>" max="15" class="form-control" readonly required>
      
      <h6><label>Reg no:</label><input type="name" name="reg" class="form-control" maxlength="15" minlength="15" placeholder="reg no"></h6>
      <h6><label>Password</label><input type="password" name="passcode" class="form-control" placeholder="password"></h6>
      <h6><label>Confirm Password</label><input type="password" name="passcode2" class="form-control" placeholder="confirm password"></h6>
        <button class="btn btn-primary" name="submit">Sign Up</button>
      <h6><a href = "index.php">back to sign in</h6>
       <?php endwhile; ?>
        </form>
    </div>
  </div>
</div>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

  $connection = mysqli_connect($host,$username,$password);
  $db = mysqli_select_db($connection,$dbname);

for ($i=16; $i<=20  ; $i++) { 
  for ($k=1000; $k<=1200; $k++){
$dept_comp[$i][$k] = "Nas/Chm/".$i."/".$k;
}
}
  $college = ($_POST['college']);
  $department = ($_POST['department']);
  $course = ($_POST['course']);
 $reg = ($_POST['reg']);
 $passcode = ($_POST['passcode']);
 $passcode2 = ($_POST['passcode2']);
$reglength = strlen($reg);

 if ($reg <= "Nas/Chm/16" or $reg <= "Nas/Chm/17" or $reg <= "Nas/Chm/18"
 or $reg <= "Nas/Chm/19" or $reg <= "Nas/Chm/20" or $reg <= "Nas/Chm/21" && $reglength<=15){
  if ($passcode!= $passcode2) {
   echo "<script>alert('Passwords do not match!')</script>";
}
else{
$select = "SELECT * FROM signup WHERE reg = '".$_POST["reg"]."'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
   echo "<script>alert('Record already exists!')</script>";
 }
  else{
  $insert = "INSERT INTO signup (college,department,course,reg,passcode,passcode2) VALUES('".$_POST["college"]."','".$_POST["department"]."','".$_POST["course"]."','".$_POST["reg"]."',
'".$_POST["passcode"]."','".$_POST["passcode2"]."')";
   mysqli_query($connection,$insert);
   echo "<script>alert('Record Successfully Inserted!')</script>";     
  }
}
}
else{
  echo "<script>alert('Invalid Registration Number!')</script>";
}
}  
?>

signupp4.php

<?php
session_start();
if (!isset($_SESSION['course'])) {
  header('location:signup.php');
}
require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM colleges WHERE course = '".$_SESSION['course']."'";
$result = mysqli_query($connection,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <strong><a class="navbar-brand" href="index.php"><img src="auk.jpg" style="width: 40px;"> Student id-card</a></strong>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="index.php"><strong>Student</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
       <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>SIGN UP PAGE<img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5>
    <?php
  while ($row = $result->fetch_assoc()):
  ?>
    <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?> 
<form action="" method="post"class="form-group">
       <label for="college">College:</label>
      <input type = "text" name="college" value="<?php echo $row["college"];?>" placeholder ="<?php echo $row["college"];?>" class="form-control" readonly required>
       <label for="department">Department:</label>
      <input type = "text" name="department" value="<?php echo $row["department"];?>" placeholder ="<?php echo $row["department"];?>" class="form-control" readonly required>
       <label for="course">Course:</label>
      <input type = "text" name="course" value="<?php echo $_SESSION["course"];?>" placeholder ="<?php echo $_SESSION["course"];?>" max="15" class="form-control" readonly required>
      
      <h6><label>Reg no:</label><input type="name" name="reg" class="form-control" maxlength="15" minlength="15" placeholder="reg no"></h6>
      <h6><label>Password</label><input type="password" name="passcode" class="form-control" placeholder="password"></h6>
      <h6><label>Confirm Password</label><input type="password" name="passcode2" class="form-control" placeholder="confirm password"></h6>
        <button class="btn btn-primary" name="submit">Sign Up</button>
      <h6><a href = "index.php">back to sign in</h6>
       <?php endwhile; ?>
        </form>
    </div>
  </div>
</div>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

  $connection = mysqli_connect($host,$username,$password);
  $db = mysqli_select_db($connection,$dbname);

for ($i=16; $i<=20  ; $i++) { 
  for ($k=1000; $k<=1200; $k++){
$dept_comp[$i][$k] = "Nas/Phy/".$i."/".$k;
}
}
  $college = ($_POST['college']);
  $department = ($_POST['department']);
  $course = ($_POST['course']);
 $reg = ($_POST['reg']);
 $passcode = ($_POST['passcode']);
 $passcode2 = ($_POST['passcode2']);
$reglength = strlen($reg);

 if ($reg <= "Nas/Phy/16" or $reg <= "Nas/Phy/17" or $reg <= "Nas/Phy/18"
 or $reg <= "Nas/Phy/19" or $reg <= "Nas/Phy/20" or $reg <= "Nas/Phy/21" && $reglength<=15){
  if ($passcode!= $passcode2) {
   echo "<script>alert('Passwords do not match!')</script>";
}
else{
$select = "SELECT * FROM signup WHERE reg = '".$_POST["reg"]."'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
   echo "<script>alert('Record already exists!')</script>";
 }
  else{
  $insert = "INSERT INTO signup (college,department,course,reg,passcode,passcode2) VALUES('".$_POST["college"]."','".$_POST["department"]."','".$_POST["course"]."','".$_POST["reg"]."',
'".$_POST["passcode"]."','".$_POST["passcode2"]."')";
   mysqli_query($connection,$insert);
   echo "<script>alert('Record Successfully Inserted!')</script>";     
  }
}
}
else{
  echo "<script>alert('Invalid Registration Number!')</script>";
}
}  
?>
