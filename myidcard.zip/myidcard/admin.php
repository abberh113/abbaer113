<?php
session_start();
if (isset($_POST['submit'])) {

$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

$connection = mysqli_connect($host,$username,$password);
$db = mysqli_select_db($connection,$dbname);

$user_name = mysqli_real_escape_string($connection,$_POST["user_name"]);
$passcode = mysqli_real_escape_string($connection,$_POST["passcode"]);

$select = "SELECT * FROM admin WHERE user_name = '$user_name' && passcode = '$passcode'";

$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
    $_SESSION['user_name'] = $user_name;
    header('location:adminloggedin.php');
 }
  else{
    $error_message = "<div class = 'alert alert-danger'>Invalid User or Password</div>";
     }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <strong><a class="navbar-brand" href="index.php"><img src="auk.jpg" style="width: 40px;"> Student id-card</a></strong>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="index.php"><strong>Student</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>    
 <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff"> 
          <h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;"><strong>ADMIN SIGN IN PAGE<img src="auk.jpg" style="width: 30px; float: left;"></strong>
</h5><?php if (!empty($error_message)) {
  echo $error_message;
} ?>
			<form action="" method="post"class="form-group">
			<h5><label>Username:</label><input type="name" name="user_name" class="form-control" placeholder="Username" maxlength="10"></h5>
			<h5><label>Password</label><input type="password" name="passcode" class="form-control" placeholder="password" min="0" max="10"></h5>
			<button class="btn btn-primary" name="submit">Login</button>
      <br>
			<a href = "adminreg.php">click here to sign up</a>
      <br>
      <a href = "forgot1.php">forgot password?</a>

        </form>
		</div>
	</div>
</div>
</body>
</html>