<?php
session_start();
if (!isset($_SESSION['user_name'])) {
header("index.php");
}
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

$connection = mysqli_connect($host,$username,$password);
$db = mysqli_select_db($connection,$dbname);

if ($_POST["passcode"] != $_POST["passcode2"]) {
 $error_message = "<div class = 'alert alert-danger'>Passwords do not match!</div>";
} else {

  $sql = "UPDATE signup set user_name ='" . $_POST["user_name"] . "', passcode ='" . $_POST["passcode"] . "', passcode2 ='" . $_POST["passcode2"] . "' WHERE user_name='" . $_SESSION['user_name']  . "'";
 mysqli_query($connection, $sql);
$success_message = "<div class = 'alert alert-success'>Password reset Successful!</div>";
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
    <a class="navbar-brand" href="admin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="admin.php"><strong>Admin</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
     <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff"> 
          <h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>ADMIN PASSWORD RESET<img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5>
        <?php if (!empty($error_message)) {
  echo $error_message;
} ?>
  <?php if(!empty($success_message)){
    echo $success_message;}
    ?>
      <form action="" method="post"class="form-group">
			<h6><label>Enter Username:</label><input type="name" value="<?php echo $_SESSION['user_name'];?>"  name="user_name" class="form-control" placeholder="<?php echo $_SESSION['user_name'];?> " maxlength="15"readonly></h6>
			<h6><label>Choose new password</label><input type="password" name="passcode" class="form-control" placeholder="Enter new password"></h6>
      <h6><label>Confirm new password</label><input type="password" name="passcode2" class="form-control" placeholder="Confirm new password"></h6>
			<button class="btn btn-primary" name="submit">Reset</button>
			<h6><a href = "admin.php">back to sign in</h6>
        </form>
		</div>
	</div>
</div>
</body>
</html>
