<?php
session_start();
if (!isset($_SESSION['course'])) {
  header('location:signup.php');
}
require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM colleges WHERE course = '".$_SESSION['course']."'";
$result = mysqli_query($connection,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <strong><a class="navbar-brand" href="index.php"><img src="auk.jpg" style="width: 40px;"> Student id-card</a></strong>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="index.php"><strong>Student</strong><img src="admin.jpg" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
       <div class="row justify-content-center">
       	<div class="col-md-6 col-xs-12">
       	<div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong>SIGN UP PAGE<img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5>
    <?php
  while ($row = $result->fetch_assoc()):
  ?>
    <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?> 
<form action="" method="post"class="form-group">
       <label for="college">College:</label>
      <input type = "text" name="college" value="<?php echo $row["college"];?>" placeholder ="<?php echo $row["college"];?>" class="form-control" readonly required>
       <label for="department">Department:</label>
      <input type = "text" name="department" value="<?php echo $row["department"];?>" placeholder ="<?php echo $row["department"];?>" class="form-control" readonly required>
       <label for="course">Course:</label>
      <input type = "text" name="course" value="<?php echo $_SESSION["course"];?>" placeholder ="<?php echo $_SESSION["course"];?>" max="15" class="form-control" readonly required>
      
      <h6><label>Reg no:</label><input type="name" name="reg" class="form-control" maxlength="15" minlength="15" placeholder="reg no"></h6>
			<h6><label>Password</label><input type="password" name="passcode" class="form-control" placeholder="password"></h6>
      <h6><label>Confirm Password</label><input type="password" name="passcode2" class="form-control" placeholder="confirm password"></h6>
      	<button class="btn btn-primary" name="submit">Sign Up</button>
			<h6><a href = "index.php">back to sign in</h6>
       <?php endwhile; ?>
        </form>
		</div>
	</div>
</div>
</body>
</html>
<?php
if (isset($_POST['submit'])) {
$host = "localhost";
$username = "root";
$password = "";
$dbname = "std_idcard";

  $connection = mysqli_connect($host,$username,$password);
  $db = mysqli_select_db($connection,$dbname);

for ($i=16; $i<=20  ; $i++) { 
  for ($k=1000; $k<=1200; $k++){
$dept_comp[$i][$k] = "Nas/Chm/".$i."/".$k;
}
}
  $college = ($_POST['college']);
  $department = ($_POST['department']);
  $course = ($_POST['course']);
 $reg = ($_POST['reg']);
 $passcode = ($_POST['passcode']);
 $passcode2 = ($_POST['passcode2']);
$reglength = strlen($reg);

 if ($reg <= "Nas/Chm/16" or $reg <= "Nas/Chm/17" or $reg <= "Nas/Chm/18"
 or $reg <= "Nas/Chm/19" or $reg <= "Nas/Chm/20" or $reg <= "Nas/Chm/21" && $reglength<=15){
  if ($passcode!= $passcode2) {
   echo "<script>alert('Passwords do not match!')</script>";
}
else{
$select = "SELECT * FROM signup WHERE reg = '".$_POST["reg"]."'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
   echo "<script>alert('Record already exists!')</script>";
 }
  else{
  $insert = "INSERT INTO signup (college,department,course,reg,passcode,passcode2) VALUES('".$_POST["college"]."','".$_POST["department"]."','".$_POST["course"]."','".$_POST["reg"]."',
'".$_POST["passcode"]."','".$_POST["passcode2"]."')";
   mysqli_query($connection,$insert);
   echo "<script>alert('Record Successfully Inserted!')</script>";     
  }
}
}
else{
  echo "<script>alert('Invalid Registration Number!')</script>";
}
}  
?>
