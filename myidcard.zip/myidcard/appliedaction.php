<?php
session_start();
 if (!isset($_SESSION['user_name'])) {
   header('location:index.php');
 }
require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM apply";
$result = mysqli_query($connection,$sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="adminloggedin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>     <div class="container-fluid">
  <div class="alert alert-info" align="center" style="background-color:darkorange"><strong>Applied Id-Cards</strong></div>
    <div class="row">
        <div class="col-md-10 col-xs-12">
        <div class="panel panel-info">
          <div class="panel-heading"></div>
          <div class="panel-body">
      
  <table class="table" style="background-color:#FffEF4">
    <thead>
      <tr>
        <th style="text-align: center">id</th>
        <th style="text-align:center">Photo</th>
        <th style="text-align:center">Reg</th>
        <th style="text-align:center">Surname</th>
        <th style="text-align:center">othernames</th>
        <th style="text-align:center">college</th>
        <th style="text-align:center">department</th>
        <th style="text-align:center">course</th>
        <th style="text-align:center">kinno</th>
        <th style="text-align:center">Action</th>
        <!--<th style="text-align:center">Delete</th>
      </tr>-->
    </thead>
    <?php
  while ($row = $result->fetch_assoc()):
  ?>
  <tbody>
  <tr>

    <td><?php echo $row["id"]; ?></td>
    <td><img src="<?php echo $row["image"]; ?>" width = "50px";></td>
    <td><?php echo $row["reg"];?></td>
    <td><?php echo $row["surname"]; ?></td>
    <td><?php echo $row["othernames"]; ?></td>
    <td><?php echo $row["college"]; ?></td>
    <td><?php echo $row["department"]; ?></td>
    <td><?php echo $row["course"]; ?></td>
    <td><?php echo $row["kinno"]; ?></td>
  
    <td><a href="appliedaction.php?action=<?php echo $row['id'];?>" 
      class = "btn btn-info"><img src="action.png" width="25px"></a></td>
     <!--     <td><a href="process.php?delete=<?php echo $row['id'];?>" 
      class = "btn btn-danger"><img src="delete.png" width="20px"></a></td>
      </tr>-->
</tbody>
<?php endwhile; ?>
  </table>
  </div>
</div>
</div>

  <?php
  function pre_r($array){
    echo '<pre>';
    print_r($array);
    echo '</pre>';
  }
  ?>
    <?php
    require_once 'process.php';
    ?> 
        <div class="col-md-2">
        <form action="gen.php" method="post">
       <input type="hidden" name="image" value="<?php if(!empty($image)){ echo $disp["image"];} ?>" placeholder="image" required class="form-control" readonly>
      <br>   
       <input type="text" name="reg" value="<?php if(!empty($reg)){ echo $disp["reg"];} ?>" placeholder="reg" required class="form-control" readonly>
      <br>
      <input type="text" name="surname" value="<?php if(!empty($surname)){ echo $disp["surname"];} ?>" placeholder = "Surname" required class="form-control" readonly>
      <br>
      <input type="hidden" name="othernames" value="<?php if(!empty($othernames)){ echo $disp["othernames"];} ?>" placeholder="othernames" required class="form-control" readonly>
      <input type="hidden" name="college" value="<?php if(!empty($college)){ echo $disp["college"];} ?>" placeholder="college" required class="form-control" readonly>
      <input type="hidden" name="department" value="<?php if(!empty($department)){ echo $disp["department"];} ?>" placeholder="department" required class="form-control" readonly>
      <input type="hidden" name="course" value="<?php if(!empty($course)){ echo $disp["course"];} ?>" placeholder="course" required class="form-control" readonly>
      <input type="hidden" name="kinno" value="<?php if(!empty($kinno)){ echo $disp["kinno"];} ?>" placeholder="kinno" required class="form-control" readonly>
      <button type="submit" name="submit" class="btn btn-primary">Generate ID</button>
    </form>
  </div>
      </div>
    </div>
</body>
</html>