<?php
$connection = mysqli_connect("localhost","root","","std_idcard");
?>