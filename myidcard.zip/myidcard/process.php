<?php
require_once 'config.php';
if (isset($_GET['action'])) {
$id = $_GET['action'];
$connection = new mysqli ("localhost","root","","std_idcard") or die($connection->error());
$result = $connection->query("SELECT * FROM apply WHERE id = $id");
if (mysqli_num_rows($result)==1){
	$disp = $result->fetch_array();
	$image = $disp["image"];
	$reg = $disp["reg"];
	$surname = $disp["surname"]; 
    $othernames = $disp["othernames"];
    $college = $disp["college"];
    $department = $disp["department"];
    $course = $disp["course"];
    $kinno = $disp["kinno"];
}
}

if (isset($_GET['delete'])) {
$id = $_GET['delete'];
$connection = new mysqli ("localhost","root","","std_idcard") or die($connection->error());
$result = $connection->query("DELETE FROM apply WHERE id = $id");
header("location:appliedaction.php");
}
?>