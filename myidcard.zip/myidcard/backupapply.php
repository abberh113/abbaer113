<?php
session_start();
if (!isset($_SESSION["reg"])) {
  header("location:index.php");
}
include 'config.php';
if(isset($_POST['submit'])){
$reg = $_POST['reg'];
$surname = $_POST['surname'];
$othernames = $_POST['othernames'];
$college = $_POST['college'];
$department = $_POST['department'];
$course = $_POST['course'];
$kinno = $_POST['kinno'];

$select = "SELECT * FROM apply WHERE reg = '$reg' && surname = '$surname'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
  echo "<div class = 'alert alert-danger'>Reg Number and or Username already taken</div>";
}
else{
  //code for image uploading
if($_FILES['f1']['name']){
   $fileinfo = @getimagesize($_FILES["file-input"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "png",
        "jpg",
        "jpeg"
    );
    
    // Get image file extension
    $file_extension = pathinfo($_FILES["f1"]["name"], PATHINFO_EXTENSION);
    if (! in_array($file_extension, $allowed_image_extension)) {
        $response = array(
            "type" => "error",
            "message" => "Upload valid images. Only PNG and JPEG are allowed."
        );
    }    // Validate image file size
    else if (($_FILES["f1"]["size"] > 5000000)) {
        $response = array(
            "type" => "error",
            "message" => "Image size exceeds 5MB"
        );
    }    // Validate image file dimension
    else if ($width > "300" || $height > "200") {
        $response = array(
            "type" => "error",
            "message" => "Image dimension should be within 300X200"
        );
    }else{
move_uploaded_file($_FILES['f1']['tmp_name'], "image/".$_FILES['f1']['name']);
$img="image/".$_FILES['f1']['name'];

$i="INSERT INTO apply(image,reg,surname,othernames,college,department,course,kinno)values('$img','$reg','$surname','$othernames','$college','$department','$course','$kinno')";
if(mysqli_query($connection, $i)){
echo "<div class = 'alert alert-success'>inserted successfully..!</div>";
}
}
}
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="loggedin.php"><img src="auk.jpg" style="width: 40px;"> student id-card</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 20px;"><strong>logout</strong></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
        <?php if(!empty($response)) { ?>
    <div class="response <?php echo $response["type"]; ?>"><?php echo $response["message"]; ?></div>
    <?php }?><br>
           <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-success">ID CARD APPLICATION PAGE<img src="auk.jpg" style="width: 30px; float: left;">
</h5>

      <form action="" enctype="multipart/form-data" method="post"class="form-group">
        <input type="file" name="f1" class="form-control" required>
      <h5><label>Reg NO:</label><input type="text" name="reg" class="form-control" placeholder="<?php echo  $_SESSION['reg'];?>" value = "<?php echo  $_SESSION['reg'];?>"  required readonly></h5>
      <h5><label>Surname</label><input type="text" name="surname" class="form-control" placeholder="Surname" required></h5>
      <h5><label>Other Names</label><input type="text" name="othernames" class="form-control" placeholder="Other Names" required></h5>
    
      <label for="college-select">College:</label>
      <select type = "text" name="college" id="pet-select" class="form-control" required>
    <option value="">--Please select your college--</option>
    <option value="NAS">NAS</option>
    <option value="HUM">HUM</option>
    <option value="SOS">SOS</option>
    <option value="EDU">EDU</option>
</select>
      <label for="department-select">Department:</label>
      <select type = "text" name="department" id="pet-select" class="form-control" required>
    <option value="">--Please select your Department--</option>
    <option value="Mth Sciences">Mth Sciences</option>
    <option value="Bio Sciences">Bio Sciences</option>
    <option value="Phy Sciences">Phy Sciences</option>
    <option value="Chm Sciences">Chm Sciences</option>
</select>

 <label for="course-select">course:</label>
      <select type = "text" name="course" id="pet-select" class="form-control" required>
    <option value="">--Please select your course--</option>
    <option value="Comp. Science">Comp. Science</option>
    <option value="Biology">Biology</option>
    <option value="Chemistry">Chemistry</option>
    <option value="EDU">EDU</option>
</select>
      
      <h5><label>Next of kin no:</label><input type="number" name="kinno" class="form-control" placeholder="Next of kin no" required></h5>
      <button class="btn btn-primary" name="submit">Apply</button>
      <br>
      <h5><a href = "loggedin.php">back</h5>
        </form>
    </div>
  </div>
</div>
</body>
</html>