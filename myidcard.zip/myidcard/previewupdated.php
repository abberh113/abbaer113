<?php
session_start();
 if (!isset($_SESSION['reg'])) {
   header('location:index.php');
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="adminloggedin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br><div class="container">
      <div class="row justify-content-center">
        <div class="col-md-0 ">
          <div class="thumbnail">
            <div  class="col-md-0">
            <div class="alert alert-success"><strong>Modifications can not be made because your Id-Card is already processed!</strong>
            </div>
          </div>            
              <h5 style="text-align: center;"><a href="previewupdate.php" >
      <a href="loggedin.php" >
      <button type="submit" class="btn btn-danger">
       Ok</button></a></h5>
</body>
</html>
