<?php
session_start();
if (!isset($_SESSION["reg"])) {
  header("location:loggedin.php");
}
include 'config.php';
if(isset($_POST['submit'])){
$reg = $_POST['reg'];
$surname = $_POST['surname'];
$othernames = $_POST['othernames'];
$college = $_POST['college'];
$department = $_POST['department'];
$course = $_POST['course'];
$kinno = $_POST['kinno'];

$select = "SELECT * FROM apply WHERE reg = '$reg'";
$result = mysqli_query($connection,$select);
$rows = mysqli_num_rows($result);
if ($rows == 1) {
  echo "<script>alert('You have already made an Application!')</script>";
}
else{
  //code for image uploading
if($_FILES['f1']['name']){
   $fileinfo = @getimagesize($_FILES["file-input"]["tmp_name"]);
    $width = $fileinfo[0];
    $height = $fileinfo[1];
    
    $allowed_image_extension = array(
        "png",
        "jpg",
        "jpeg"
    );
    
    // Get image file extension
    $file_extension = pathinfo($_FILES["f1"]["name"], PATHINFO_EXTENSION);
    if (! in_array($file_extension, $allowed_image_extension)) {
        $response = array(
            "type" => "error",
            "message" => "Upload valid images. Only PNG and JPEG are allowed."
        );
    }    // Validate image file size
    else if (($_FILES["f1"]["size"] > 5000000)) {
        $response = array(
            "type" => "error",
            "message" => "Image size exceeds 5MB"
        );
    }    // Validate image file dimension
    else if ($width > "300" || $height > "200") {
        $response = array(
            "type" => "error",
            "message" => "Image dimension should be within 300X200"
        );
    }else{
move_uploaded_file($_FILES['f1']['tmp_name'], "image/".$_FILES['f1']['name']);
$img="image/".$_FILES['f1']['name'];

$i="INSERT INTO apply(image,reg,surname,othernames,college,department,course,kinno)values('$img','$reg','$surname','$othernames','$college','$department','$course','$kinno')";
if(mysqli_query($connection, $i)){
echo "<script>alert('Application Successful!')</script>";
}
}
}
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="loggedin.php"><strong><img src="auk.jpg" style="width: 40px;"> Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
<br>
           <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-info" style="background-color: darkorange">ID CARD APPLICATION PAGE<img src="auk.jpg" style="width: 30px; float: left;">
</h5>
  <h5 style="text-align: center;"><a href="preview.php" >
      <button type="submit" class="btn btn-primary">
       Preview</button></h5>
  <h5 style="text-align: center;"><a href="loggedin.php" >
      <button type="submit" class="btn btn-danger">
       Back</button></h5>
</div>
</div>
</div>
</body>
</html>

