<?php
session_start();
if (!isset($_SESSION["reg"])) {
  header("location:index.php");
}
  require_once("config.php");
$connection = new mysqli ("localhost","root","","std_idcard") or die(mysqli_error($sql));
$sql = "SELECT * FROM signup WHERE reg = '".$_SESSION['reg']."'";
$result = mysqli_query($connection,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="loggedin.php"><img src="auk.jpg" style="width: 40px;"><strong>student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
<br>
           <div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff;">
<h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;"><strong>ID CARD APPLICATION PAGE<img src="auk.jpg" style="width: 30px; float: left;"></strong>
</h5>
   
      <form action="applyform.php" enctype="multipart/form-data" method="post"class="form-group">
        <input type="file" name="f1" class="form-control" required>
      <h5><label>Reg NO:</label><input type="text" name="reg" class="form-control" placeholder="<?php echo  $_SESSION['reg'];?>" value = "<?php echo  $_SESSION['reg'];?>"  required readonly></h5>
      <h5><label>Surname:</label><input type="text" name="surname" class="form-control" placeholder="Surname" required ></h5>
      <h5><label>Othernames</label><input type="text" name="othernames" class="form-control" placeholder="Othernames"  required ></h5>

      <?php while ($row = $result->fetch_assoc()):?>
      <h5><label>College:</label><input type="text" name="college" class="form-control" placeholder="<?php echo  $row['college'];?>" value = "<?php echo  $row['college'];?>"  required readonly></h5>
      <h5><label>Department</label><input type="text" name="department" class="form-control" placeholder="<?php echo  $row['department'];?>" value = "<?php echo  $row['department'];?>"  required readonly></h5>
      <h5><label>Course:</label><input type="text" name="course" class="form-control" placeholder="<?php echo  $row['course'];?>" value = "<?php echo  $row['course'];?>"  required readonly></h5>    
      <?php endwhile; ?>  
      <h5><label>Next of kin no:</label><input type="number" name="kinno" class="form-control" placeholder="Next of kin no" required></h5>
      <button class="btn btn-primary" name="submit">Apply</button>
      <br>
      <h5><a href = "loggedin.php">back</h5>
        </form>
    </div>
  </div>
</div>
</body>
</html>

