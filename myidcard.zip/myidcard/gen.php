<?php
session_start();
require_once 'config.php';
if (isset($_POST["submit"])) {
   $connection = new mysqli ("localhost","root","","std_idcard") or die($connection->error());
   $image = $_POST["image"];
   $reg = $_POST["reg"];
   $surname = $_POST["surname"];
   $othernames = $_POST["othernames"];
   $college = $_POST["college"];
   $department = $_POST["department"];
   $course = $_POST["course"];
   $kinno = $_POST["kinno"];   
   $query = "SELECT * FROM apply  WHERE reg = '$reg'";
   $result = mysqli_query($connection,$query);
   $rows = mysqli_num_rows ($result);
   if ($rows ==1) {
    $_SESSION["image"] = $image;
    $_SESSION["reg"] = $reg;
    $_SESSION["surname"] = $surname;
    $_SESSION["othernames"] = $othernames;
    $_SESSION["college"] = $college;
    $_SESSION["department"] = $department;
    $_SESSION["course"] = $course;
    $_SESSION["kinno"] = $kinno;
    }
    ?>
    <?php
    require_once "db.php";
   $select = "SELECT * FROM status  WHERE reg = '".$_SESSION['reg']."'";
   $display = mysqli_query($connection,$select);
   $row = mysqli_num_rows ($display);
   if ($row==1) {
      header("location:generate2.php");
    }else{
      $i="INSERT INTO status(image,reg,surname,othernames,college,department,course,kinno)values('$image','$reg','$surname','$othernames','$college','$department','$course','$kinno')";
mysqli_query($connection, $i);
      header('location:generate.php');  
        }
}
?>