<?php
session_start();
if (!isset($_SESSION['reg'])) {
  header("location:index.php");
}
?>
<?php
if (isset($_POST["check"])) {
  require_once "db.php";
   $select = "SELECT * FROM status  WHERE reg = '".$_SESSION['reg']."'";
   $display = mysqli_query($connection,$select);
   $row = mysqli_num_rows ($display);
   if ($row==1) {
      $success_message = "<div class = 'alert alert-success'>Your id card is ready for collection, thank you!</div>";
    }else{
    $error_message = "<div class = 'alert alert-danger'>Your id card is not yet ready for collection, thank you!</div>";
  }
}


if (isset($_POST["lost"])) {
  require_once "db.php";
   $select = "SELECT * FROM apply  WHERE reg = '".$_SESSION['reg']."'";
   $display = mysqli_query($connection,$select);
   $row = mysqli_num_rows ($display);
   if ($row==1) {
    header("location:lost.php");
    }
    else{
    $error_message = "<div class = 'alert alert-danger'>Apply for Id-Card,thank you!</div>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
<a class="navbar-brand" href="loggedin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>
<br>
<div class="container fluid">
<div class="row justify-content-center">
        <div class="col-md-6 col-xs-12">
        <div class="jumbotron" style="background-color: #fefcff"> 
          <h5 align="center" class="alert alert-info" style="background-color:darkorange; color: black;">
            <strong><?php echo $_SESSION['reg']; ?><img src="auk.jpg" style="width: 30px; float: left;">
</strong></h5> <br>
 <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?>
      <h5 style="text-align: center;"><a href="apply.php" ><button type="button" class="btn btn-primary">Apply for Std Id-Card</button></a></h5>
        <br>
           <form action="" method="post">
           <h5 style="text-align: center;">
      <button type="submit" name="check" class="btn btn-success">
       Check for availability</button></h5>
     </form>
     <br>
           <h5 style="text-align: center;"><a href="lostid.php" >
      <button type="submit" class="btn btn-danger">
       Lost Id-Card Enquiry</button></h5>
         	</div>
	</div>
</div>
</body>
</html>