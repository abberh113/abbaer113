<?php
session_start();
 if (!isset($_SESSION['user_name'])) {
   header('location:index.php');
 }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>auk-student-id-card</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #e5e4e2; 
background-image: url(class.jpg);
background-size:cover; ">

<nav class="navbar navbar-expand-md bg-info navbar-light">
  <a class="navbar-brand" href="adminloggedin.php"><strong><img src="auk.jpg" style="width: 40px;">Student id-card</strong></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-end" id="collapsibleNavbar">
    <ul class="nav navbar-nav">
      <li class="nav-item">
        <a class="nav-link"  href="logout.php"><img src="logout.png" style="width: 25px;"></a>
      </li>    
    </ul>
  </div>  
</nav>

    <?php if (!empty($error_message)) {
  echo $error_message;
} ?> 
    <?php if (!empty($success_message)) {
  echo $success_message;
} ?> 
<br><div class="container">
      <div class="row justify-content-center">
        <div class="col-md-0 ">
          <div class="thumbnail">
            <div  class="col-md-0">
            <div class="alert alert-danger"><strong>Id-Card Already Processed!</strong></div>
          </div>              <div class="card mb-3 box-shadow" style="background-color: white;
              width: 305px; height: 190px" >
                  <div class="card-body" style="width:smaller; height: smaller;">
<img src="auk.jpg" style="width: 30px; float: left;">
<h6><small><strong style="color: red">AL QALAM UNIVERSITY KATSINA</strong></small></h6>
  <img src='<?php echo $_SESSION["image"]; ?>' style="
    width: 40px;
    height: 50px;
    background-color: #FFF; float: right;">
    <p><small><h6 >NAME: <small> <?php echo $_SESSION["surname"];?>
    <?php echo $_SESSION["othernames"];?></small></h6>
    REG:<?php echo $_SESSION["reg"];?>
    <br>
    DEPT: <?php echo $_SESSION["department"];?>
    <br>
    NEXT OF KIN NO : <?php echo $_SESSION["kinno"];?>
    <p style="background-color: red;color: white;">STUDENT ID CARD <small style="float: right;">Valid  till 2025</small> </p>
  <div class="d-flex justify-content-between align-items-center">
  </div>
</small>
</p>
</div>
</div>
<br>
<br>
   <div class="card mb-3 box-shadow" style="background-color: white;
              width: 305px; height: 190px" >
              <div class="card-body" style="width:smaller; height: smaller;">
<small><img src="auk.jpg" style="width: 40px; float: right;">
   <h6><small>This is to certify that the bearer whose picture and name appear
    on this card is a bonafide student of: <br>
  <strong align = "center">AL-QALAM UNIVERSITY,KATSINA</strong><img src="qrcode.jpg" style="width: 80px; float: right;"><br>
  <small>P.M.B 2137, Dutsinma Road, Katsina</small>
  <br>
  Please if found, please return to the <br>
  overleaf address nearest police station.</small></h6>
</div></small>
</div>
</div>
<div><button class="btn btn-success" onClick="window.print()">Print this page
</button></div>
</div>
</div>
</body>
</html>
